# Encrypted by Venom

z="
";Dz=' '\''\n';Gz='et -';Lz='l Ve';Kz='meta';Pz=' ven';Qz='om';Az='clea';Mz='nomB';Ez='\n'\''';Jz=' -F ';Oz='node';Fz='toil';Hz='F bo';Cz='echo';Bz='r';Nz='ot';Iz='rder';
eval "$Az$Bz$z$Cz$Dz$Ez$z$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$z$Oz$Pz$Qz"