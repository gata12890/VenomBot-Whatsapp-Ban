clear
apt-get update && apt-get upgrade
pkg install nodejs
pkg install toilet
pkg install mpv 
clear
echo "\033[1;32m obrigado por instala esta script ❤️😍"

sh venom.sh

